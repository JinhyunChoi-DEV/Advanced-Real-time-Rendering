
#pragma once


#include <glbinding/nogl.h>

#include <glbinding/gl14ext/types.h>
#include <glbinding/gl14ext/values.h>
#include <glbinding/gl14ext/boolean.h>
#include <glbinding/gl14ext/bitfield.h>
#include <glbinding/gl14ext/enum.h>
#include <glbinding/gl14ext/functions.h>

#include <glbinding/gl/extension.h>