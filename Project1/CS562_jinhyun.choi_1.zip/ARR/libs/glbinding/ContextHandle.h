
#pragma once


namespace glbinding
{


using ContextHandle = long long int; ///< Type for storing context handles


} // namespace glbinding