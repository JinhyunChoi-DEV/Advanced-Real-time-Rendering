
#pragma once


#include <glbinding/nogl.h>

#include <glbinding/gl/values.h>


namespace gl12
{


// import values to namespace


} // namespace gl12