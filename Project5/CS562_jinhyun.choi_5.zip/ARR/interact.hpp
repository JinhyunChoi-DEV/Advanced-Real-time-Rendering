#pragma once
void InitInteraction(GLFWwindow* window);