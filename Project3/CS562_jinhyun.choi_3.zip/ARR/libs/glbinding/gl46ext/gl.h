
#pragma once


#include <glbinding/nogl.h>

#include <glbinding/gl46ext/types.h>
#include <glbinding/gl46ext/values.h>
#include <glbinding/gl46ext/boolean.h>
#include <glbinding/gl46ext/bitfield.h>
#include <glbinding/gl46ext/enum.h>
#include <glbinding/gl46ext/functions.h>

#include <glbinding/gl/extension.h>