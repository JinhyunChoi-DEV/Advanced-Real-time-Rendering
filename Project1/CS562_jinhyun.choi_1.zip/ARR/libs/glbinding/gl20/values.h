
#pragma once


#include <glbinding/nogl.h>

#include <glbinding/gl/values.h>


namespace gl20
{


// import values to namespace


} // namespace gl20