
#pragma once


#include <glbinding/nogl.h>

#include <glbinding/gl/values.h>


namespace gl11
{


// import values to namespace


} // namespace gl11