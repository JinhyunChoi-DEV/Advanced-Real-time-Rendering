
#pragma once


#include <glbinding/nogl.h>

#include <glbinding/gl46/types.h>
#include <glbinding/gl46/values.h>
#include <glbinding/gl46/boolean.h>
#include <glbinding/gl46/bitfield.h>
#include <glbinding/gl46/enum.h>
#include <glbinding/gl46/functions.h>

#include <glbinding/gl/extension.h>